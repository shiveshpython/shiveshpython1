<!-- PHP Programs to demonstrate arrays -->
<html>
    <head>
        <title>
            Hello
</title>
</head>
<body>
    <?php
    $people = array("Abster", "Aryaman");
    print_r($people); // prints the array: Array ( [0] => Abster [1] => Aryaman )
    echo $people[1]; //prints the values at the index

    ?>
    </body>
    </html>