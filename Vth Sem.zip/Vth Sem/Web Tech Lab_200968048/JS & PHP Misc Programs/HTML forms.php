<!-- PHP Program to take input from HTML Forms -->
<html>
    <head>
        <title>
            Hello
</title>
</head>
<body>
<form action="process.php" method="post">
    Enter Name: <input name="name" type="text">
    <input type="submit">
    </body>
    </html>
