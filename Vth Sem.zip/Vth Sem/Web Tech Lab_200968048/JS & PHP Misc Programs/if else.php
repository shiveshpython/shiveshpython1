<!--  PHP program to demonstrate if else -->
<html>
    <head>
        <title>
            Hello
</title>
</head>
<body>
    <?php


$log = true;
if ($log == true) {
    echo " Logged In";
} else {
    echo " Not Logged In";
}
    
    
    ?>
    </body>
    </html>
