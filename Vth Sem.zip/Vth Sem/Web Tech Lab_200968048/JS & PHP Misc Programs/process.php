<?php
$name = $_POST["name"]; // whatever name given in input is to be put here
echo "Hello, " . $name;
?>
