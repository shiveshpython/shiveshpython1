## Vth Sem Folder

This folder contains programs for the Vth Sem Labs:

- [Operating Systems](https://github.com/absterjr/Mit-Manipal-DSE-Lab/tree/main/Vth%20Sem/OS_200968048)
- [Web Technologies](https://github.com/absterjr/Mit-Manipal-DSE-Lab/tree/main/Vth%20Sem/Web%20Tech%20Lab_200968048)
- [Deep Learning](https://github.com/absterjr/Mit-Manipal-DSE-Lab/tree/main/Vth%20Sem/DL_200968048)
